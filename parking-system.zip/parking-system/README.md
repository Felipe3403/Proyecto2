# Sistema de Gestión de Parqueadero

Sistema para administrar un parqueadero con 40 puestos numerados.

## Características

- Gestión de 40 puestos de parqueo
- Registro de entrada y salida de vehículos
- Control de tarifas por hora
- Reportes de disponibilidad e ingresos
- Horario de operación: 6:00 - 21:00

## Tecnologías

- Python 3.8+
- FastAPI (Backend)
- SQLite (Base de datos)
- React (Frontend)

## Instalación

1. Clonar el repositorio
2. Instalar dependencias:
```bash
pip install -r requirements.txt
npm install
```

3. Ejecutar el servidor:
```bash
uvicorn main:app --reload
```

4. Ejecutar el cliente:
```bash
npm start
```

## Estructura del Proyecto

```
parking-system/
├── backend/
│   ├── main.py
│   ├── models.py
│   └── database.py
├── frontend/
│   ├── src/
│   └── package.json
└── requirements.txt
```