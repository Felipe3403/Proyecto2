from datetime import datetime
from typing import Optional
from pydantic import BaseModel, constr
from sqlalchemy import Column, Integer, String, DateTime, Float, ForeignKey
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()
